package org.eclipse.nebula.widgets.collapsiblebuttons;

public class DefaultLanguageManager extends AbstractLanguageManager {

}
