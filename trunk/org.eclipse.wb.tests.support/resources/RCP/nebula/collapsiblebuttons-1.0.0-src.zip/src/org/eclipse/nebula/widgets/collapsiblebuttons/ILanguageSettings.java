package org.eclipse.nebula.widgets.collapsiblebuttons;

public interface ILanguageSettings {

	public String getShowFewerButtonsText();
	public String getShowMoreButtonsText();
	public String getAddOrRemoveButtonsText();
}
