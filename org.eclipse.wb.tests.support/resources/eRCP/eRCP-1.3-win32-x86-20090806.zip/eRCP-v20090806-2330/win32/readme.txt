This archive contains eRCP runtimes for Windows x86.  These runtimes have been tested to work 
with J2SE 1.3.x, J2SE 1.4.x and IBM J9 2.2.

Prerequisites:  J2SE 1.3.x, J2SE 1.4.x, or J9 2.2. When using J2SE, java.exe is assumed to be in the windows
execution path.

Installation on Windows x86:  extract this archive to a folder.  If 
using IBM J9 JVM, you may need to set the IVEHOME environment variable 
to point to the IBM Device Developer installation.

Running:  There are three ways to launch the runtime:
  j9foun-hello.bat will start an OSGi console and launch a simple eSWT hello application.
  j9foun-demo.bat  will start an OSGi console and launch an eSWT demo application.
  j9foun-eworkbench.bat will start an OSGI console and launch the eWorkbench which includes a simple sample application.

Documentation:  JavaDoc for eSWT and eJFace can be found in zip format at www.eclipse.org/ercp. 
  JavaDoc for other components is available through CVS.

Any questions or comments should be directed to the eRCP newgroup.  
See http://www.eclipse.org/ercp
